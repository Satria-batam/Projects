/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
//import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.LinkedHashMap;
import java.util.Map;
import com.google.gson.Gson;
/**
 *
 * @author User
 */
@WebServlet(urlPatterns = {"/tictactoecontroller"})
public class tictactoecontroller extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
        
            
            if(request.getParameter("action").equals("initialize"))
            {
                initialize(request, response);//initialize game
            }else if(request.getParameter("action").equals("updatemove"))
            {
                movePlayer(request,response);//save every movement of player
            }else if(request.getParameter("action").equals("reset"))
            {
                resetGame(request,response);//reset game
            }
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    /*
    initialize game board,player etc.
    */
    public void initialize(HttpServletRequest request, HttpServletResponse response)
            throws IOException
    {
        HttpSession sesi=request.getSession(true);//request session
        
        String player1,player2,boardStr;
        Integer row,column;
        
        //sent by client
        player1 = request.getParameter("player1");//get player1's name
        player2 = request.getParameter("player2");//get player2's name
        row = Integer.parseInt(request.getParameter("row"));//get row
        column = Integer.parseInt(request.getParameter("column"));//get column

        Board board = new Board(row, column, player1, player2);//create an object of Class Board
        boardStr = board.getBoard();//create a board
        
        String firstmove = board.getCurrentPlayer();//set first player to move
        
        sesi.setAttribute("board", board);//make a session. and set object board to it
        
        //set information set to client formatted by JSON 
        Map<String, String> ind = new LinkedHashMap<String, String>();
        ind.put("board", boardStr);
        ind.put("firstmove", firstmove);
        ind.put("labelCurrPlayer", board.getLabelPlayer()); 
    
 
        String json = null ; 
        json= new Gson().toJson(ind);
    
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(json);//return to client
    
    
    }
    
    /*
    save every movement of player
    */
    public void movePlayer(HttpServletRequest request, HttpServletResponse response)
        throws IOException{
        
        HttpSession sesi=request.getSession(true);//request session
        
        Board board =(Board) sesi.getAttribute("board");//get previous object
        
        String pos = request.getParameter("pos");//get new position of cell'client
        String currplayer = request.getParameter("currplayer");//get current player

        //set position's player
        String status_movement =board.setMovement(pos,currplayer);
        
        //set information set to client formatted by JSON 
        Map<String, String> ind = new LinkedHashMap<String, String>();
        ind.put("status",status_movement );
        ind.put("currPlayer", board.getCurrentPlayer());
        ind.put("labelCurrPlayer", board.getLabelPlayer()); 

        String json = null ; 
        json= new Gson().toJson(ind);
    
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(json);//return to client

    }
    
    /*
    reset game
    */
    public void resetGame(HttpServletRequest request, HttpServletResponse response)
            throws IOException
    {
        HttpSession sesi = request.getSession(true);//request session
        sesi.removeAttribute("board");//remove previous session
        
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write("1");//return to client
    }
}
