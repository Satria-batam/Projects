
import java.util.Random;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class Board {
    private String Board="",labelCross="X",labelNought="O";//set label for cross and nought
    private Integer nRow,nColumn;//declare row & column
    private final String CLASSROW="row",CLASSCOLUMN="column",CLASSCARD="card";//set name of CLASS to html
    private boolean isPlay=false;
    private static final String EMPTY = "-";//default value for empty cell in board
    private static String CROSS,NOUGHT,currentPlayer;//declare variable for player
        
    public static final String DELIMETER = "_";
    public static String[][] board;//declare array board
    
    /*
    set construct board
    */
    public Board(Integer nRow,Integer nColumn,String Player1, String Player2)
    {
        this.nRow = nRow;
        this.nColumn = nColumn;
        this.isPlay = true;
        
        this.CROSS = Player1;
        this.NOUGHT = Player2;
    }
    
    /*
    generate form of board, row and column set by client
    */
    private void generateBoard()
    {
        board = new String[nRow][nColumn];
        
        this.randomFirstMove();
        
        for(int row=0;row<nRow;row++)
        {
            //create board for HTML
            Board +="<div class="+CLASSROW+">";
            for(int col=0;col<nColumn;col++)
            {
                //add Column
                Board +="<div class="+CLASSCOLUMN+" data-pos="+row+"_"+col+">";//set data position of cell to get position of cell click by client format [row_column]
                Board +="<div class="+CLASSCARD+">";
                Board +="<h3>-</h3> </div></div>";
                
                //set to empty all cell
                board[row][col] = EMPTY;  // all cells empty
            }
            Board +="</div>";
        }
    }
    
    /*
    call generate board
    */
    public String getBoard()
    {
        this.generateBoard();
        return this.Board;
    }
    
    public boolean isPlay()
    {
        return this.isPlay;
    }
    
    /*
    set current player
    */
    public void setCurrentPlayer(String Player)
    {
        currentPlayer = Player;
    }
    
    /*
    get current player
    */
    public String getCurrentPlayer()
    {
        return currentPlayer;
    }
    
    /*
    random first user who is moving first
    */
    private void randomFirstMove()
    {
        Random rng = new Random();
        
        int i = rng.nextInt(2);
        
        if(i == 1)
            this.setCurrentPlayer(this.CROSS);
        else
            this.setCurrentPlayer(this.NOUGHT);
    }
    
    /*
    get label of each user
    */
    public String getLabelPlayer()
    {
        if(CROSS == currentPlayer)
            return labelCross;
        else
            return labelNought;
    }
    
    /*
    process of game
    return is winner,draw, empty(means game is not over) 
    */
    public String setMovement(String position,String currplayer)
    {
        String [] pos= position.split(DELIMETER);//explode position cell by '_'
        Integer row = Integer.parseInt(pos[0]); //set row
        Integer column = Integer.parseInt(pos[1]); //set column
        boolean isWon =false, isDraw=false;
        if(board[row][column].equals("-"))
        {
            board[row][column] = currplayer; //set player name for choosed cell on board 
        }
        
        isWon = hasWon(row, column);//check whether there a winner ?
        isDraw = isDraw();//check game is draw ?
        if(isWon)
        {
            return "winner is "+currplayer;//return message has a winner
        }else if(isDraw)
        {
            return "draw";//return message game is draw
        }else
        {
            swapCurrentPlayer(currplayer);//set next player to move
            return "";//return message game is not over
        }
        
            
    }
    
    /*
    change next player to move
    */
    private void swapCurrentPlayer(String currplayer)
    {
        String cp = currplayer;
        if(CROSS.equals(currplayer))
        {
            cp = NOUGHT;
                            
        }else
        {
            cp = CROSS;
                             
        }
        setCurrentPlayer(cp);       
    }
         
    /*
    find a pattern for current client to know is he/she win  
    */
    public boolean hasWon(int currRow, int currColumn)
    {
        
        //check straight
        boolean straight = false,diagonal = false;
        straight = checkStraight(currRow, currColumn);
        //check diagonal
        if((currColumn+1) == nColumn || (currColumn-1) <= 0 || currColumn == nColumn-1 ){
            diagonal = checkDiagonal(currRow, currColumn);
        }
        
        if(straight || diagonal)
            return true;
        else 
            return false;
        
    }
    
    /*
    check pattern for diagonal
    */
    private boolean checkDiagonal(int currRow, int currColumn)
    {
        int diagonalAfter_count = 0;
        int diagonalBefore_count = 0;
        
        int startColumnAfter = nColumn-1;
        int startColumnBefore = 0;
                
        for(int row=0;row<nRow;row++)
        {
            //check diagonal for right side
            if(board[row][startColumnAfter].equals(currentPlayer))
            {
                diagonalAfter_count++;//count pattern
                startColumnAfter--;
            }
            //check diagonal for left side
            if(board[row][startColumnBefore].equals(currentPlayer))
            {
                diagonalBefore_count++;//count pattern
                startColumnBefore++;
            }
        }
        
        if(diagonalAfter_count == nColumn || diagonalBefore_count == nColumn)
            return true;
        else 
            return false;
    }
    
    /*
    check pattern for Straight
    */
    private boolean checkStraight(int currRow, int currColumn)
    {
        int vertical_count = 0;
        int horizontal_count = 0;
        
        for(int row=0;row<nRow;row++)
        { 
            
            //vertical pattern
            if(board[row][currColumn].equals(currentPlayer))
            {
               
                vertical_count++; 
            }
            //vertical pattern
            if(currRow == row)
            {
                for(int column=0;column<nColumn;column++)
                {
                    if(board[row][column].equals(currentPlayer))
                    {
                        horizontal_count++; 
                    }
                }
            }
             
        }
        
        if(vertical_count == nColumn || horizontal_count == nColumn)
            return true;
        else 
            return false;
    }
    
    /*
    check game is draw
    */
    private boolean isDraw()
    {
        for(int row=0;row<nRow;row++)
        { 
            for(int column=0;column<nColumn;column++)
            {
                if(board[row][column] == EMPTY)
                {
                    return false;
                }
            }
        }
        
        return true;
    }
}
